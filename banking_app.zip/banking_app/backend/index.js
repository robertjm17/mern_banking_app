// include express
const express = require("express");

// include mongoose for database
const mongoose = require("mongoose");

// include cors for cross-site requests
const cors = require("cors");
require("dotenv").config();

// set up our express
// using cors
const app = express();
app.use(express.json());
app.use(cors());

// set up our port
const PORT = process.env.PORT || 5000;

// start listening
app.listen(PORT, () => console.log(`Server Started on PORT: ${PORT}.`));

// this key is used to connect to our MongoDB database
const key = process.env.MONGODB_CONNECTION_STRING;

// set up our mongoose
mongoose.connect(key, { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true, useFindAndModify: false}, (err) =>
    {
        if (err) throw err;
        console.log("Connection Established with MongoDB Databse.");
    }
);

// routes
// can be used to perform predefined actions without using front end
app.use("/users", require("./routes/userRouter"));
app.use("/savings", require("./routes/savingsRouter"));
app.use("/checking", require("./routes/checkingRouter"));
app.use("/transaction", require("./routes/transactionRouter"));
