// icnlude jason-web-token
// used for tokens to check login status
const jwt = require("jsonwebtoken");

// authentication
// this is used to check that the user is logged in when performing actions
const authenticator = (req, res, next) => {
    try {
        // get token
        const token = req.header("login_token");

        // if there is no token
        if (!token)
            return res.status(401).json({ msg: "Not authorized, no token." });
        
        // check if token is authentic
        const tokenCheck = jwt.verify(token, process.env.SECRET_KEY)

        // if token is not authentic
        if (!tokenCheck)
            return res.status(401).json({ msg: "Not authorized, incorrect token." });

        // no error
        // save user information for later use
        req.user = tokenCheck.id;

        // moves on to the action the user is taking
        next();
    
    // error handling
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
  };

  // export authenticator
  module.exports = authenticator;