// mongoose will be used to access MongoDB database
const mongoose = require('mongoose');

// mongoose.Schema is used to create object type
const Schema = mongoose.Schema;

// this is the checking account schema
// it is used to represent all of the checking accounts in the system
const checkingSchema = new Schema({
  // this is the checking account number
  // it is used for clerical reasons since an ID is already assigned within the database
  accountNumber: {type: Number},
  
  // this is the amount of funds that reside in this checking account
  funds: {type: Number},
});

// create Checking
const Checking = mongoose.model('Checking', checkingSchema);

// export Checking
module.exports = Checking;