// mongoose will be used to access MongoDB database
const mongoose = require('mongoose');

// mongoose.Schema is used to create object type
const Schema = mongoose.Schema;

// transaction schema
// this is used to represent all the transactions that occur in the system
const transactionSchema = new Schema({
  // this is the name of the user who carreid out the transaction
  merchantName: {type: String, required: true},
  
  // this is the date the transaction occured
  date: {type: Date, required: true},

  // this is the amount of funds transfered between accounts
  funds: {type: Number, required: true},
}, {
});

// create Transaction
const Transaction = mongoose.model('Transaction', transactionSchema);

// export Transaction
module.exports = Transaction;