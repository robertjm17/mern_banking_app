// mongoose will be used to access MongoDB database
const mongoose = require('mongoose');

// mongoose.Schema is used to create object type
const Schema = mongoose.Schema;

// user schema
// this will be used to represent each of the users in the system
const userSchema = new Schema({
  // this is the users usernmae
  username: {type: String, required: true},
  
  // this is the users password
  // it will be encrypted before bing stored in the database
  password: {type: String, required: true},

  // this is the users account number
  // it is used for clerical reasons
  accountNumber: {type: Number, required: true},

  // this is the users savings account
  // the ID for this savingsAccount is saved as a memebr of this user
  savingsAccount: {type: mongoose.Schema.Types.ObjectId, required: true},

  // this is the users checking account
  // the ID for this checkingAccount is saved as a memebr of this user
  checkingAccount: {type: mongoose.Schema.Types.ObjectId, required: true},

  // this is the users transaction record
  // this is used to store the users past transactions
  records: {type: [mongoose.Schema.Types.Transaction]},
}, {
});

// create user
const User = mongoose.model('User', userSchema);

// exprot user
module.exports = User;