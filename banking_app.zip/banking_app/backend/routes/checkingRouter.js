// include router
const router = require('express').Router();

// make use of the Checking model
let Checking = require('../models/checking.model');

// add checking account to system
router.route('/add').post((req, res) => {
  try {
    // variables
    const accountNumber = Number(req.body.accountNumber);
    const funds = Number(req.body.funds);
  
    // create new checking account
    const newChecking = new Checking({accountNumber, funds});
  
    // saves new checking account
    newChecking.save()
    res.json('CheckingAccount Added!')
    
    // if error occurs show error message
    // should not happend since all users are predefined in system
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// export
module.exports = router;