// include router
router = require('express').Router();

// make use of the Savings model
let Savings = require('../models/savings.model');

// add savings account to system
router.route('/add').post((req, res) => {
  try {
    // variables
    const accountNumber = Number(req.body.accountNumber);
    const funds = Number(req.body.funds);
  
    // create new savings account
    const newSavings = new Savings({accountNumber, funds});
  
    // saves new savings account
    newSavings.save()
    res.json('SavingsAccount Added!')
    
    // if error occurs show error message
    // should not happend since all users are predefined in system
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// export
module.exports = router;