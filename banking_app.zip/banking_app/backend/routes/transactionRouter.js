// include router
const router = require('express').Router();

// make use of the Transaction model
let Transaction = require('../models/transaction.model');

router.post("/add", async (req, res) => {
  try {
    // read in data for predefined user
    const merchantName = req.body.merchantName;
    const date = Date.parse(timestamps);
    const funds = Number(req.body.funds);

    // create new transaction
    const newTransaction = new Transaction({merchantName,date,funds,});

    // saves new transaction
    newTransaction.save()
    
    // if error occurs show error message
    // should not happend since all users are predefined in system
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// export
module.exports = router;