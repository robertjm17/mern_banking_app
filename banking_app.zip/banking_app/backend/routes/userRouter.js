// include router
const router = require("express").Router();

// include bcrypt
// used for encryption
const bcrypt = require("bcryptjs");

// make use of the User model
const User = require("../models/user.model");

// make use of the User model
const Savings = require("../models/savings.model");

// make use of the User model
const Checking = require("../models/checking.model");

// make use of the Transaction model
const Transaction = require("../models/transaction.model");

// include jwt jason-web-token
// this will be used to make use of tokins for login authentication
const jwt = require("jsonwebtoken");

// used for searching for ObjectID's
const ObjectId = require('mongodb').ObjectId; 

//include 

// include authenticator
// this is used to ensure that a token is valid
const authenticator = require("../middleware/authenticator");
const { findOne } = require("../models/user.model");

// create user
// only used to predfine users within the system
// users will not have acces to this in the web app
router.post("/add", async (req, res) => {
  try {
    // read in data for predefined user
    const username = req.body.username;
    const password = req.body.password;
    const accountNumber = Number(req.body.accountNumber);
    const savingsAccount = req.body.savingsAccount
    const checkingAccount = req.body.checkingAccount

    // encrypt password
    const encrptor = await bcrypt.genSalt();
    const passwordHash = await bcrypt.hash(password, encrptor);

    // creates new 
    // stores encrypt password in databse for safety
    const newUser = new User({username, password: passwordHash, accountNumber, savingsAccount, checkingAccount});

    // saves user
    newUser.save()
    res.json('New User Added!')
    
    // error handling
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// login user
router.post("/login", async (req, res) => {
  try {
    // read in data for predefined user
    const username = req.body.username;
    const password = req.body.password;

    // check to make sure that inputs were entered
    if (!username || !password)
      return res.status(400).json({ msg: "Not all field information has been entered." })

    // check to see if user exists
    const user = await User.findOne({ username: username });
    
    // if user is not predfined in system
    if (!user)
      return res.status(400).json({ msg: "User does not exist." });

    // checks if user password is valid
    const passwordCheck = await bcrypt.compare(password, user.password);

    // if the password does not match
    if (!passwordCheck)
      return res.status(400).json({ msg: "Incorrect Password." });

    // key that we have for security reasons
    const key = process.env.SECRET_KEY;
    
    // create web token
    // stores id for user
    // signifies a succesful user login into the system
    const token = jwt.sign({ id: user._id }, key);

    // confirmation of login
    res.json({token, user: {id: user._id, username: user.username, accountNumber: user.accountNumber, savingsAccount: user.savingsAccount, checkingAccount: user.checkingAccount}})

    // error handling
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// used for web app to adjust based off of user being logged in or not
router.post("/loggedin", async (req, res) => {
  try{
    // fetch token
    const token = req.header("login_token");

    // if there is no token 
    // then a user is not logged into the ssytem
    if (!token)
        return res.json(false);

    // key that we have for security reasons
    const key = process.env.SECRET_KEY;
    
    // check if token that exists is valid
    const tokenCheck = jwt.verify(token, key)

    // if the token is not valid
    // the user is not allowed to login to the system
    if (!tokenCheck)
        return res.json(false);

    // if the token is valid then a user is logged into the system
    return res.json(true);

    // error handling
  } catch(err)
  {
    res.status(500).json({ error: err.message });
  }
});

// get user info from backend
router.get("/getdata", authenticator, async (req, res) => {
  try{
    // search for user information
    const user = await User.findById(req.user);
    const savings = await Savings.findById(user.savingsAccount);
    const checking = await Checking.findById(user.checkingAccount);

    // return user data
    // return savings data
    // return checking data
    res.json(
      {
          id: user._id, 
          username: user.username, 
          accountNumber: user.accountNumber, 
          savingsAccount: user.savingsAccount, 
          savingsAccountNumber: savings.accountNumber,
          savingsAccountFunds: savings.funds,
          checkingAccount: user.checkingAccount,
          checkingAccountNumber: checking.accountNumber,
          checkingAccountFunds: checking.funds,
          records: user.records
      });

    // error handling
  } catch(err)
  {
    res.status(500).json({ error: err.message });
  }
});

// create transaction
router.post("/transaction", async (req, res) => {
  try{
    // search for user information
    const user1 = await User.findById(req.body.user);
    let user2 = null;
    
    // used to check account type of account1
    const a1S = await Savings.findOne({accountNumber: req.body.account1});
    const a1C = await Checking.findOne({accountNumber: req.body.account1});

    // used to check account type of account2
    const a2S = await Savings.findOne({accountNumber: req.body.account2});
    const a2C = await Checking.findOne({accountNumber: req.body.account2});

    // funds to be transferred
    const fundsAmmount = req.body.funds;

    // default account values are bull
    let account1 = null;
    let account2 = null;

    // determine account type of account1
    if (a1S != null)
      account1 = a1S;
    else
      account1 = a1C;
    
    // determine account type of account2
    if (a2S != null) {
      account2 = a2S;
    }
      
    else {
      account2 = a2C;
    }
    
    // update account1 funds
    if (a1S != null)
    {
      await Savings.findByIdAndUpdate((account1._id), {accountNumber: account1.accountNumber, funds: parseFloat(account1.funds) - parseFloat(fundsAmmount)});
    }
    
    else
    {
      await Checking.findByIdAndUpdate((account1._id), {accountNumber: account1.accountNumber, funds: parseFloat(account1.funds) - parseFloat(fundsAmmount)});
    }
      
    
    // update account2 funds
    if (a2S != null)
    {
      await Savings.findByIdAndUpdate((account2._id), {accountNumber: account2.accountNumber, funds: parseFloat(account2.funds) + parseFloat(fundsAmmount)});
      
      // find user 2 using account2
      user2 = await User.findOne({savingsAccount: ObjectId(account2._id)});
    }
    
    else
    {
      await Checking.findByIdAndUpdate((account2._id), {accountNumber: account2.accountNumber, funds: parseFloat(account2.funds) + parseFloat(fundsAmmount)});
      
      // find user 2 using account2
      user2 = await User.findOne({checkingAccount: ObjectId(account2._id)});
    }

    // create new transaction
    const merchantName = user1.username;
    const date = Date.parse(new Date());
    const funds = Number(fundsAmmount).toFixed(2);

    // create new transaction
    const newTransaction = new Transaction({ merchantName, date, funds });

    // saves new transaction
    newTransaction.save()

    // transaction between accounts
    if (String(user1._id) != String(user2._id)) {
      // update record for user1
      await User.findByIdAndUpdate((user1._id), {$push: {records: { newTransaction }}});

      // update record for user2
      await User.findByIdAndUpdate((user2._id), {$push: {records: { newTransaction }}});
    } else {
       // update record for user1
       await User.findByIdAndUpdate((user1._id), {$push: {records: { newTransaction }}});
    }
    
    // add transaction to user record
    res.json("Performed Transaction");
    
    // error handling
  } catch(err)
  {
    res.status(500).json({ error: err.message });
  }
});

// export
module.exports = router;
