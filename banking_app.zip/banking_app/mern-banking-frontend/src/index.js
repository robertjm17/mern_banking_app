// React will be used to build this js file
import React from 'react';

// this will be used to render from end
import ReactDOM from 'react-dom';

// allows for index.js to utilize the App.js file and its App funtion
import App from './App';

// render front end
ReactDOM.render(<App />, document.querySelector("#root"));

