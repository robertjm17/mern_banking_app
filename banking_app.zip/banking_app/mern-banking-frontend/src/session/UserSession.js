// this is imported to use user states from data
import { createContext } from "react";

// default
export default createContext(null);